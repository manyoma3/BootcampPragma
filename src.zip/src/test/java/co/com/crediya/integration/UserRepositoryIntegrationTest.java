package co.com.crediya.integration;

import co.com.crediya.infrastructure.entity.UserEntity;
import co.com.crediya.infrastructure.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.r2dbc.DataR2dbcTest;
import org.springframework.test.context.ActiveProfiles;
import reactor.test.StepVerifier;

import java.time.LocalDate;

@DataR2dbcTest
@ActiveProfiles("test")
class UserRepositoryIntegrationTest {

    @Autowired
    private UserRepository userRepository;

    @BeforeEach
    void clean() {
        userRepository.deleteAll().block();
    }

    @Test
    void shouldPersistAndRetrieveUser() {
        UserEntity entity = UserEntity.builder()
                .nombres("Juan")
                .apellidos("Gómez")
                .fechaNacimiento(LocalDate.of(1990, 5, 10))
                .direccion("Calle 45")
                .telefono("3111111111")
                .correoElectronico("juan@example.com")
                .salarioBase(2000000.0)
                .build();

        StepVerifier.create(userRepository.save(entity).then(userRepository.findByCorreoElectronico("juan@example.com")))
                .expectNextMatches(found -> found.getCorreoElectronico().equals("juan@example.com") && found.getSalarioBase().equals(2000000.0))
                .verifyComplete();
    }
}
