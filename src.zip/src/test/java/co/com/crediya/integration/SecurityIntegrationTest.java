package co.com.crediya.integration;


import co.com.crediya.infrastructure.config.SecurityConfig;
import co.com.crediya.infrastructure.router.AuthRouter;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;

@WebFluxTest // carga solo el stack WebFlux
@Import({SecurityConfig.class, AuthRouter.class})
class SecurityIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @Test
    void loginDebeSerPublico() {
        webTestClient.post()
                .uri("/api/v1/login")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("""
                    {"email":"admin@crediya.com","password":"admin123"}
                """)
                .exchange()
                .expectStatus().isOk(); // debería entrar al handler, no 401
    }

    @Test
    void usuariosDebeExigirToken() {
        webTestClient.post()
                .uri("/api/v1/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("""
                    {"nombre":"Prueba"}
                """)
                .exchange()
                .expectStatus().isUnauthorized(); // sin token → 401
    }
}
