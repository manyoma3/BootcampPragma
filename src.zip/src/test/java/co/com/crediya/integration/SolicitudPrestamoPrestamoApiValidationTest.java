package co.com.crediya.integration;

import co.com.crediya.infrastructure.repository.SolicitudPrestmoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.time.OffsetDateTime;
import java.util.UUID;

@SpringBootTest
@AutoConfigureWebTestClient
class SolicitudPrestamoPrestamoApiValidationTest {

    @Autowired
    private WebTestClient webTestClient;

    @Autowired
    private SolicitudPrestmoRepository solicitudRepository;

    @BeforeEach
    void clean() {
        solicitudRepository.deleteAll().block();
    }

    @Test
    void shouldReturnBadRequestWhenMontoIsInvalid() {
        String requestJson = "{"
                + "\"documentoCliente\":\"123456789\","
                + "\"monto\":0,"
                + "\"plazoMeses\":24,"
                + "\"tipoPrestamo\":\"personal\""
                + "}";

        // Headers requeridos
        String messageId = UUID.randomUUID().toString();
        String applicationId = "solicitudPrestamos-app";
        String requestDateTime = OffsetDateTime.now().toString();

        webTestClient.post()
                .uri("/api/v1/solicitudPrestamo")
                .header("messageId", messageId)
                .header("applicationId", applicationId)
                .header("requestDateTime", requestDateTime)
                .contentType(org.springframework.http.MediaType.APPLICATION_JSON) //
                .accept(org.springframework.http.MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.data.error").isEqualTo("VALIDATION_ERROR")
                .jsonPath("$.data.message").isEqualTo("Monto y plazo deben ser mayores a 0");
    }

    @Test
    void shouldReturnBadRequestWhenTipoPrestamoIsInvalid() {
        String requestJson = "{"
                + "\"documentoCliente\":\"123456789\","
                + "\"monto\":5000000,"
                + "\"plazoMeses\":24,"
                + "\"tipoPrestamo\":\"prestamo_raro\""
                + "}";

        // Headers requeridos
        String messageId = UUID.randomUUID().toString();
        String applicationId = "solicitudPrestamos-app";
        String requestDateTime = OffsetDateTime.now().toString();

        webTestClient.post()
                .uri("/api/v1/solicitudPrestamo")
                .header("messageId", messageId)
                .header("applicationId", applicationId)
                .header("requestDateTime", requestDateTime)
                .contentType(org.springframework.http.MediaType.APPLICATION_JSON) //
                .accept(org.springframework.http.MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.data.error").isEqualTo("VALIDATION_ERROR")
                .jsonPath("$.data.message").isEqualTo("Tipo de préstamo inválido");
    }
}
