package co.com.crediya.integration;

import co.com.crediya.infrastructure.repository.SolicitudPrestmoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.time.OffsetDateTime;
import java.util.UUID;

@SpringBootTest
@AutoConfigureWebTestClient
class SolicitudPrestamoPrestamoApiIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @Autowired
    private SolicitudPrestmoRepository solicitudRepository;

    @BeforeEach
    void clean() {
        solicitudRepository.deleteAll().block();
    }

    @Test
    void shouldRegisterSolicitudPrestamoEndToEnd() {
        // JSON bien formado
        String requestJson = """
            {
              "documentoCliente": "123456789",
              "monto": 5000000,
              "plazoMeses": 24,
              "tipoPrestamo": "personal"
            }
            """;

        // Headers requeridos
        String messageId = UUID.randomUUID().toString();
        String applicationId = "crediya-app";
        String requestDateTime = OffsetDateTime.now().toString();

        webTestClient.post()
                .uri("/api/v1/solicitudPrestamo")
                .header("messageId", messageId)
                .header("applicationId", applicationId)
                .header("requestDateTime", requestDateTime)
                .contentType(org.springframework.http.MediaType.APPLICATION_JSON) //
                .accept(org.springframework.http.MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/json")
                .expectBody()
                .jsonPath("$.data.id").isNotEmpty()
                .jsonPath("$.data.documentoCliente").isEqualTo("123456789")
                .jsonPath("$.data.monto").isEqualTo(5000000)
                .jsonPath("$.data.plazoMeses").isEqualTo(24)
                .jsonPath("$.data.tipoPrestamo").isEqualTo("personal")
                .jsonPath("$.data.estado").isEqualTo("Pendiente de revisión");
    }
}
