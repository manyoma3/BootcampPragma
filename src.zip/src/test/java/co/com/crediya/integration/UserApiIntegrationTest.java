package co.com.crediya.integration;

import co.com.crediya.infrastructure.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.time.OffsetDateTime;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
class UserApiIntegrationTest {

    @Autowired
    private WebTestClient webTestClient;

    @Autowired
    private UserRepository userRepository;

    @BeforeEach
    void clean() {
        userRepository.deleteAll().block();
    }

    @Test
    void shouldRegisterUserEndToEnd() {
        String requestJson = "{"
                + "\"nombres\":\"Carla\","
                + "\"apellidos\":\"Lopez\","
                + "\"fechaNacimiento\":\"1992-08-15\","
                + "\"direccion\":\"Carrera 50 #123\","
                + "\"telefono\":\"3102223344\","
                + "\"correoElectronico\":\"carla@example.com\","
                + "\"salarioBase\":3500000.0"
                + "}";

        // Headers requeridos
        String messageId = UUID.randomUUID().toString();
        String applicationId = "crediya-app";
        String requestDateTime = OffsetDateTime.now().toString();

        webTestClient.post()
                .uri("/api/v1/usuarios")
                .header("messageId", messageId)
                .header("applicationId", applicationId)
                .header("requestDateTime", requestDateTime)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.data.correoElectronico").isEqualTo("carla@example.com");

        var saved = userRepository.findByCorreoElectronico("carla@example.com").block();
        assertThat(saved).isNotNull();
        assertThat(saved.getNombres()).isEqualTo("Carla");
    }


    @Test
    void shouldFailWhenEmailAlreadyExists() {
        String requestJson = "{"
                + "\"nombres\":\"Luis\","
                + "\"apellidos\":\"Martínez\","
                + "\"fechaNacimiento\":\"1985-04-10\","
                + "\"direccion\":\"Av 10\","
                + "\"telefono\":\"3201112233\","
                + "\"correoElectronico\":\"luis@example.com\","
                + "\"salarioBase\":1500000.0"
                + "}";

        // Headers requeridos
        String messageId = UUID.randomUUID().toString();
        String applicationId = "crediya-app";
        String requestDateTime = OffsetDateTime.now().toString();

        webTestClient.post()
                .uri("/api/v1/usuarios")
                .header("messageId", messageId)
                .header("applicationId", applicationId)
                .header("requestDateTime", requestDateTime)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isOk();

        webTestClient.post()
                .uri("/api/v1/usuarios")
                .header("messageId", messageId)
                .header("applicationId", applicationId)
                .header("requestDateTime", requestDateTime)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestJson)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.data.error").isEqualTo("VALIDATION_ERROR")
                .jsonPath("$.data.message").isEqualTo("El correo ya está registrado");
    }
}
