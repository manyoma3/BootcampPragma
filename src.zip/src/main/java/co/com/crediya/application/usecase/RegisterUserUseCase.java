package co.com.crediya.application.usecase;

import co.com.crediya.domain.model.User;
import co.com.crediya.infrastructure.entity.UserEntity;
import co.com.crediya.infrastructure.mapper.UserMapper;
import co.com.crediya.infrastructure.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Objects;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class RegisterUserUseCase {

    private final UserRepository userRepository;

    // Patrón regex para validar correos electrónicos
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");

    // Metodo principal para registrar usuario
    public Mono<User> registerUser(User user) {
        return validate(user)
                .then(userRepository.findByCorreoElectronico(user.getCorreoElectronico())
                        //Si el correo existe, devuelve un error reactivo
                        .flatMap(existing -> Mono.error(new IllegalArgumentException("El correo ya está registrado")))
                        //Si no existe (switchIfEmpty), convierte el User de dominio en una entidad (UserEntity) y lo guarda en la base de datos.
                        .switchIfEmpty(Mono.defer(() -> {
                            UserEntity entity = UserMapper.toEntity(user);
                            return userRepository.save(entity);
                        }))
                        .map(o -> UserMapper.toDomain((UserEntity) o)) // Mapea de entidad a modelo de dominio
                );
    }

    private Mono<Void> validate(User user) {
        if (Objects.isNull(user.getNombres()) || user.getNombres().isBlank()) {
            return Mono.error(new IllegalArgumentException("El campo nombres es obligatorio"));
        }
        if (Objects.isNull(user.getApellidos()) || user.getApellidos().isBlank()) {
            return Mono.error(new IllegalArgumentException("El campo apellidos es obligatorio"));
        }
        if (Objects.isNull(user.getCorreoElectronico()) || user.getCorreoElectronico().isBlank()) {
            return Mono.error(new IllegalArgumentException("El campo correo electrónico es obligatorio"));
        }
        if (!EMAIL_PATTERN.matcher(user.getCorreoElectronico()).matches()) {
            return Mono.error(new IllegalArgumentException("El formato del correo electrónico es inválido"));
        }
        if (Objects.isNull(user.getSalarioBase())) {
            return Mono.error(new IllegalArgumentException("El campo salario base es obligatorio"));
        }
        if (user.getSalarioBase() < 0 || user.getSalarioBase() > 15000000) {
            return Mono.error(new IllegalArgumentException("El salario base debe estar entre 0 y 15,000,000"));
        }
        return Mono.empty(); //si todo esta bien retorna vacio sin error
    }
}
