package co.com.crediya.application.usecase;

import co.com.crediya.domain.model.SolicitudPrestamo;
import co.com.crediya.infrastructure.mapper.SolicitudPrestamoMapper;
import co.com.crediya.infrastructure.repository.SolicitudPrestmoRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class ListarSolicitudesUseCase {

    private final SolicitudPrestmoRepository repo;

    /*public Mono<co.com.crediya.infrastructure.entrypoints.dto.PagedResponse<SolicitudPrestamo>> list(int page, int size, String tipoFiltro, String emailFiltro) {
        List<String> estados = Arrays.asList("Pendiente de revisión", "Rechazadas", "Revision manual");
        int offset = page * size;

        log.debug("ListarSolicitudesUseCase.list page={} size={} tipo={} email={}", page, size, tipoFiltro, emailFiltro);

        return repo.countByEstados(estados, tipoFiltro, emailFiltro)
                .defaultIfEmpty(0L)
                .flatMap(total ->
                        repo.findByEstadosPaged(estados, tipoFiltro, emailFiltro, size, offset)
                                .map(SolicitudPrestamoMapper::toDomain)
                                .collectList()
                                .map(list -> co.com.crediya.infrastructure.entrypoints.dto.PagedResponse.<SolicitudPrestamo>builder()
                                        .items(list)
                                        .total(total)
                                        .page(page)
                                        .size(size)
                                        .build()
                                )
                );
    }*/
}

