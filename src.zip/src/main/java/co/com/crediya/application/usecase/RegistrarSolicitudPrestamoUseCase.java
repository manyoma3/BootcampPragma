package co.com.crediya.application.usecase;

import co.com.crediya.domain.model.SolicitudPrestamo;
import co.com.crediya.infrastructure.entity.SolicitudPrestamoEntity;
import co.com.crediya.infrastructure.mapper.SolicitudPrestamoMapper;
import co.com.crediya.infrastructure.repository.SolicitudPrestmoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
//Mono de Project Reactor, que representa una operación
// reactiva que emite cero o un resultado de forma asíncrona.
import reactor.core.publisher.Mono;

@Service //indica que esta clase es un componente de servicio de Spring.
@RequiredArgsConstructor //crea un constructor automático con los campos final, facilitando la inyección de dependencias.
// Inyección del repositorio que maneja la persistencia de las solicitudes
public class RegistrarSolicitudPrestamoUseCase {

    private final SolicitudPrestmoRepository solicitudPrestmoRepository;

    public Mono<SolicitudPrestamoEntity> registrar(SolicitudPrestamo solicitudPrestamo) {
        // Convierte el modelo de dominio a una entidad persistente
        SolicitudPrestamoEntity entity = SolicitudPrestamoMapper.toEntity(solicitudPrestamo);
        // Guarda la entidad en la base de datos y devuelve un Mono con el resultado
        return solicitudPrestmoRepository.save(entity);
    }
}
