// application/usecase/LoginUseCase.java
package co.com.crediya.application.usecase;

import co.com.crediya.domain.model.AuthUser;
import co.com.crediya.infrastructure.mapper.AuthUserMapper;
import co.com.crediya.infrastructure.repository.AuthUserRepository;
import co.com.crediya.infrastructure.service.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/*Este código representa un caso de uso de inicio de sesión (Login).
Su función principal es:
-Buscar un usuario por email.
-Validar su contraseña.
-Generar un token JWT si las credenciales son válidas.*/
@Component
@RequiredArgsConstructor
public class LoginUseCase {
    private final AuthUserRepository repo;
    private final JwtService jwt;
    //private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
    private final PasswordEncoder encoder;


    public Mono<String> login(String email, String rawPassword) {
        System.out.println(">>> LoginUseCase.login() llamado con email=" + email + " password=" + rawPassword);

        // Buscar al usuario en la base de datos por su email
        return repo.findByEmail(email)
                // Si no se encuentra el usuario, lanzar un error
                .switchIfEmpty(Mono.defer(() -> {
                    System.out.println(">>> Usuario NO encontrado en DB con email=" + email);
                    return Mono.error(new org.springframework.security.authentication.BadCredentialsException("Credenciales inválidas"));
                }))
                // Convertir la entidad encontrada a un objeto de dominio
                .map(AuthUserMapper::toDomain)
                // Una vez convertido, se validan sus credenciales
                .flatMap(u -> {
                    System.out.println(">>> Usuario encontrado: " + u.getEmail() + " role=" + u.getRole() + " enabled=" + u.isEnabled());
                    System.out.println(">>> Password hash en DB=" + u.getPasswordHash());

                    // Verificar si la contraseña ingresada coincide con el hash almacenado
                    boolean matches = encoder.matches(rawPassword, u.getPasswordHash());
                    System.out.println(">>> ¿Password coincide? " + matches);

                    // Si el usuario está habilitado y la contraseña es correcta, generar token JWT
                    return (u.isEnabled() && matches)
                            ? Mono.just(jwt.generate(u))
                            : Mono.error(new org.springframework.security.authentication.BadCredentialsException("Credenciales inválidas"));
                });
    }
}

