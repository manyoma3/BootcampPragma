package co.com.crediya.domain.model;

import lombok.Builder;
import lombok.Value;

@Value @Builder
public class AuthUser {
    Long id;
    String email;
    String passwordHash;
    Role role;
    String documento; // para validación de cliente
    boolean enabled;
}
