package co.com.crediya.domain.model;

public enum Role { ADMIN, ASESOR, CLIENTE }

