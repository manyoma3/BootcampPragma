package co.com.crediya.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data //Genera getters, setters, toString(), equals() y hashCode()
@Builder //Permite construir objetos usando el patrón Builder, lo que facilita la creación de instancias con muchos campos.
@NoArgsConstructor //Genera un constructor vacío (sin parámetros).
@AllArgsConstructor //Genera un constructor con todos los campos como parámetros.
public class SolicitudPrestamo {
    private Long id;
    private String documentoCliente;
    private Double monto;
    private Integer plazoMeses;
    private String tipoPrestamo;
    private String estado; // "Pendiente de revisión"
}

