package co.com.crediya.infrastructure.router;

import co.com.crediya.infrastructure.handler.SolicitudListHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;

import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RequestPredicates.accept;

@Configuration
public class SolicitudRouter {

    /*@Bean
    public RouterFunction<?> solicitudRoutes(SolicitudListHandler handler) {
        return RouterFunctions.route(GET("/api/v1/solicitud").and(accept(MediaType.APPLICATION_JSON)), handler::listar);
    }*/
}
