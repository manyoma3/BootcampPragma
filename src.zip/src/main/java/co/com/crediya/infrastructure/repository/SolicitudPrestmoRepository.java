package co.com.crediya.infrastructure.repository;

import co.com.crediya.infrastructure.entity.SolicitudPrestamoEntity;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

public interface SolicitudPrestmoRepository extends ReactiveCrudRepository<SolicitudPrestamoEntity, String> {
}
