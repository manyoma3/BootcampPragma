// infrastructure/entity/AuthUserEntity.java
package co.com.crediya.infrastructure.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Data
@Table("auth_users")
public class AuthUserEntity {
    @Id Long id;
    String email;

    @Column("password_hash")
    String passwordHash;

    String role;
    String documento;
    Boolean enabled;
}
