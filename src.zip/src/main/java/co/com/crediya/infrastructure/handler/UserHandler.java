package co.com.crediya.infrastructure.handler;

import co.com.crediya.application.usecase.RegisterUserUseCase;
import co.com.crediya.domain.model.User;
import co.com.crediya.infrastructure.entrypoints.dto.ApiResponse;
import co.com.crediya.infrastructure.entrypoints.dto.Meta;
import co.com.crediya.infrastructure.entrypoints.dto.UserRequest;
import co.com.crediya.infrastructure.entrypoints.dto.UserResponse;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
//Clases del modelo funcional de WebFlux (handlers basados en funciones, no en controladores con anotaciones).
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

@Component
@RequiredArgsConstructor
public class UserHandler {

    private static final Logger log = LoggerFactory.getLogger(UserHandler.class);
    private final RegisterUserUseCase registerUserUseCase;

    public Mono<ServerResponse> register(ServerRequest request) {
        return request.bodyToMono(UserRequest.class)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("El cuerpo de la solicitud está vacío")))
                .doOnNext(req -> log.debug("Received register request for email={}", req.getCorreoElectronico())) //Registra en los logs el correo recibido para rastreo o depuración.
                .map(req -> User.builder()
                        .nombres(req.getNombres())
                        .apellidos(req.getApellidos())
                        .fechaNacimiento(req.getFechaNacimiento())
                        .direccion(req.getDireccion())
                        .telefono(req.getTelefono())
                        .correoElectronico(req.getCorreoElectronico())
                        .salarioBase(req.getSalarioBase())
                        .build())
                .flatMap(registerUserUseCase::registerUser)
                .map(user -> {
                    UserResponse resp = new UserResponse();
                    resp.setId(user.getId());
                    resp.setNombres(user.getNombres());
                    resp.setApellidos(user.getApellidos());
                    resp.setFechaNacimiento(user.getFechaNacimiento());
                    resp.setDireccion(user.getDireccion());
                    resp.setTelefono(user.getTelefono());
                    resp.setCorreoElectronico(user.getCorreoElectronico());
                    resp.setSalarioBase(user.getSalarioBase());
                    return resp;
                })
                .flatMap(resp -> {
                    String messageId = request.headers().firstHeader("messageId");
                    String applicationId = request.headers().firstHeader("applicationId");
                    String requestDateTime = OffsetDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);

                    Meta meta = new Meta(messageId, requestDateTime, applicationId);
                    ApiResponse<UserResponse> response = new ApiResponse<>(meta, resp);

                    return ServerResponse.ok()
                            .contentType(MediaType.APPLICATION_JSON)
                            .bodyValue(response);
                });
    }
}
