package co.com.crediya.infrastructure.repository;

import co.com.crediya.infrastructure.entity.UserEntity;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Mono;

//Importa la interfaz base de repositorios reactivas en Spring (R2dbcRepository).
//R2DBC = Reactive Relational Database Connectivity.
//Soporta operaciones asincrónicas sobre bases de datos relacionales.
public interface UserRepository extends R2dbcRepository<UserEntity, Long> {
    Mono<UserEntity> findByCorreoElectronico(String correoElectronico);
}
