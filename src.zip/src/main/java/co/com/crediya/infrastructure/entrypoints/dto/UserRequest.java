package co.com.crediya.infrastructure.entrypoints.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class UserRequest {
    private String nombres;
    private String apellidos;
    private LocalDate fechaNacimiento;
    private String direccion;
    private String telefono;
    private String correoElectronico;
    private Double salarioBase;
}
