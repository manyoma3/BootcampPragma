package co.com.crediya.infrastructure.entrypoints.dto;

import lombok.Data; // Anotación que genera getters, setters y otros métodos automáticamente

@Data
public class SolicitudPrestamoRequest {
    private String documentoCliente;
    private Double monto;
    private Integer plazoMeses;
    private String tipoPrestamo;
}
