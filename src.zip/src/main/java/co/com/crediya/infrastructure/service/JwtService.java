// infrastructure/service/JwtService.java
package co.com.crediya.infrastructure.service;

import co.com.crediya.domain.model.AuthUser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.time.Instant;
import java.util.Date;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class JwtService {

    @Value("${jwt.secret}") private String secret;
    @Value("${jwt.issuer}") private String issuer;
    @Value("${jwt.expirationMinutes}") private long expMin;

    private Key key;

    @PostConstruct
    void init() { key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8)); }

    public String generate(AuthUser user) {
        Instant now = Instant.now();
        Instant exp = now.plusSeconds(expMin * 60);

        return Jwts.builder()
                .setIssuer(issuer)                           // issuer
                .setSubject(user.getEmail())                 // subject = email
                .setIssuedAt(Date.from(now))
                .setExpiration(Date.from(exp))
                .addClaims(Map.of(
                        "role", user.getRole().name(),
                        "doc",  user.getDocumento(),
                        "uid",  user.getId()
                ))
                .signWith(key)
                .compact();
    }
}
