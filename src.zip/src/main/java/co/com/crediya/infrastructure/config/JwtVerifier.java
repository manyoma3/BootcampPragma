// infrastructure/config/JwtVerifier.java
package co.com.crediya.infrastructure.config;

import io.jsonwebtoken.Claims; // Representa los claims (datos) contenidos en el JWT
import io.jsonwebtoken.Jwts; // Clase principal para parsear y construir JWTs
import io.jsonwebtoken.security.Keys; // Utilidad para generar claves de firma seguras
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.Key;

/*Esta clase es un validador de tokens JWT. Su función es verificar que un token JWT:
Sea válido (firma correcta)
Provenga del emisor esperado (issuer)
Y luego extraer los claims (información embebida en el token*/

@Component
public class JwtVerifier {
    private final Key key;
    private final String issuer;


    // Constructor que recibe el secreto y el issuer desde application.properties
    public JwtVerifier(@Value("${jwt.secret}") String secret,
                       @Value("${jwt.issuer}") String issuer) {

        // Crea una clave HMAC SHA a partir del secreto, usando codificación UTF-8
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        // Guarda el issuer para usarlo luego en la validación del token
        this.issuer = issuer;
        System.out.println(">>> JwtVerifier inicializado con issuer=" + issuer);
    }

    public Claims parse(String token) {
        System.out.println(">>> JwtVerifier.parse() llamado con token=" + token);

        Claims claims = Jwts.parserBuilder()
                .setSigningKey(key)
                .requireIssuer(issuer)
                .build()
                .parseClaimsJws(token)
                .getBody();

        System.out.println(">>> Token válido. Claims extraídos:");
        System.out.println("    - subject=" + claims.getSubject());
        System.out.println("    - issuer=" + claims.getIssuer());
        System.out.println("    - role=" + claims.get("role"));
        System.out.println("    - expiration=" + claims.getExpiration());

        return claims;
    }
}

