// infrastructure/router/AuthRouter.java
package co.com.crediya.infrastructure.router;

import co.com.crediya.infrastructure.handler.AuthHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import static org.springframework.web.reactive.function.server.RequestPredicates.accept;
import static org.springframework.web.reactive.function.server.RequestPredicates.POST;

@Configuration
public class AuthRouter {
    @Bean
    RouterFunction<ServerResponse> authRoutes(AuthHandler h) {
        return RouterFunctions.route(POST("/api/v1/login").and(accept(MediaType.APPLICATION_JSON)), h::login);
    }
}
