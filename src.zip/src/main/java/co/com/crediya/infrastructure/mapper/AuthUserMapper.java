package co.com.crediya.infrastructure.mapper;

import co.com.crediya.domain.model.AuthUser;
import co.com.crediya.domain.model.Role;
import co.com.crediya.infrastructure.entity.AuthUserEntity;

public class AuthUserMapper {
    public static AuthUser toDomain(AuthUserEntity e) {
        return AuthUser.builder()
                .id(e.getId())
                .email(e.getEmail())
                .passwordHash(e.getPasswordHash())
                .role(Role.valueOf(e.getRole()))
                .documento(e.getDocumento())
                .enabled(Boolean.TRUE.equals(e.getEnabled()))
                .build();
    }
}
