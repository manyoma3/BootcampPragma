package co.com.crediya.infrastructure.repository;

import co.com.crediya.infrastructure.entity.SolicitudPrestamoEntity;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public interface SolicitudPrestamoRepositoryCustom {
    Mono<Long> countByEstados(List<String> estados, String tipo, String email);
    Flux<SolicitudPrestamoEntity> findByEstadosPaged(List<String> estados, String tipo, String email, int limit, int offset);
}
