package co.com.crediya.infrastructure.entrypoints.dto;

import lombok.Builder;
import lombok.Value;

import java.util.List;

@Value
@Builder
public class PagedResponse<T> {
    List<T> items;
    long total;
    int page;
    int size;
}
