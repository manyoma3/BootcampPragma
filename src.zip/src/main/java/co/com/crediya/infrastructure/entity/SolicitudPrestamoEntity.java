package co.com.crediya.infrastructure.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data; // Getters, setters, equals, hashCode, toString
import lombok.NoArgsConstructor;
// Anotaciones de Spring Data R2DBC (reactiva)
import org.springframework.data.annotation.Id;  // Clave primaria
import org.springframework.data.relational.core.mapping.Column; // Mapea columna específica
import org.springframework.data.relational.core.mapping.Table; // Mapea tabla

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table("solicitudPrestamos")
public class SolicitudPrestamoEntity {
    @Id
    private Long id;

    @Column("documento_cliente")
    private String documentoCliente;

    @Column("monto")
    private Double monto;

    @Column("plazo_meses")
    private Integer plazoMeses;

    @Column("tipo_prestamo")
    private String tipoPrestamo;

    @Column("estado")
    private String estado;
}

