package co.com.crediya.infrastructure.repository;

import co.com.crediya.infrastructure.entity.AuthUserEntity;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;

public interface AuthUserRepository extends ReactiveCrudRepository<AuthUserEntity, Long> {
    Mono<AuthUserEntity> findByEmail(String email);
}