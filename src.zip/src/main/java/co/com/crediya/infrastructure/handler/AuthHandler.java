// infrastructure/handler/AuthHandler.java
package co.com.crediya.infrastructure.handler;

import co.com.crediya.application.usecase.LoginUseCase;
import co.com.crediya.infrastructure.entrypoints.dto.LoginRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class AuthHandler {
    private final LoginUseCase useCase;

    public Mono<ServerResponse> login(ServerRequest req) {
        return req.bodyToMono(LoginRequest.class)
                .flatMap(body -> {
                    // 👇 Aquí logueas lo que llega desde Postman
                    System.out.println(">>> LOGIN REQUEST: email=" + body.getEmail() + " password=" + body.getPassword());

                    return useCase.login(body.getEmail(), body.getPassword())
                            .flatMap(token -> {
                                // 👇 Aquí logueas el token generado
                                System.out.println(">>> TOKEN generado: " + token);

                                return ServerResponse.ok()
                                        .contentType(MediaType.APPLICATION_JSON)
                                        .bodyValue("{\"token\":\"" + token + "\"}");
                            });
                });
    }
}
