package co.com.crediya.infrastructure.router;

import co.com.crediya.infrastructure.handler.SolicitudPrestamoHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import static org.springframework.web.reactive.function.server.RequestPredicates.POST;

@Configuration
public class SolicitudPrestamoRouter {

    @Bean
    public RouterFunction<ServerResponse> solicitudRoutes(SolicitudPrestamoHandler handler) {
        return RouterFunctions
                .route(POST("/api/v1/solicitudPrestamo"), handler::registrar);
    }
}

