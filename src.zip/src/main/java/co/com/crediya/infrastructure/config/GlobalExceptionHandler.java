package co.com.crediya.infrastructure.config;

import co.com.crediya.infrastructure.entrypoints.dto.ApiResponse;
import co.com.crediya.infrastructure.entrypoints.dto.Meta;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j; //habilita el uso del logger log automáticamente (Slf4j = Simple Logging Facade for Java).
import org.springframework.boot.web.reactive.error.ErrorWebExceptionHandler;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

@Component // clase como un bean gestionado por Spring Componente Spring
@Order(-2) // Prioridad de ejecución alta para manejar errores antes que otros handlers
@Slf4j // Habilita logging con 'log'
@RestControllerAdvice // Aplica manejo de errores a controladores REST
public class GlobalExceptionHandler implements ErrorWebExceptionHandler {

    private final ObjectMapper mapper;

    public GlobalExceptionHandler(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    @Override
    public Mono<Void> handle(ServerWebExchange exchange, Throwable ex) {
        log.error("Handling exception: {}", ex.getMessage(), ex);

        if (exchange.getResponse().isCommitted()) {
            return Mono.error(ex);
        }

        // Configurar estado HTTP y código de error según el tipo de excepción
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
        String code = "INTERNAL_ERROR";
        if (ex instanceof IllegalArgumentException) {
            status = HttpStatus.BAD_REQUEST;
            code = "VALIDATION_ERROR";
        }else if (ex instanceof NullPointerException) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            code = "NULL_POINTER";
        } else if (ex instanceof RuntimeException) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            code = "UNEXPECTED_ERROR";
        }

        // Si es error interno, no se muestra el mensaje real
        String errorMessage = ex.getMessage();
        if (status == HttpStatus.INTERNAL_SERVER_ERROR) {
            errorMessage = "Ocurrió un error inesperado. Intente más tarde.";
        }

        if (ex instanceof org.springframework.security.access.AccessDeniedException) {
            status = HttpStatus.FORBIDDEN;
            code = "ACCESS_DENIED";
        } else if (ex instanceof org.springframework.security.authentication.BadCredentialsException) {
            status = HttpStatus.UNAUTHORIZED;
            code = "UNAUTHORIZED";
        }

        // Construir metadatos desde headers y fecha del sistema
        String messageId = exchange.getRequest().getHeaders().getFirst("messageId");
        String applicationId = exchange.getRequest().getHeaders().getFirst("applicationId");
        String requestDateTime = OffsetDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
        Meta meta = new Meta(messageId, requestDateTime, applicationId);

        // Construir cuerpo de error
        Map<String, Object> errorData = Map.of(
                "status", status.value(),
                "title", status.getReasonPhrase(),
                "error", code,
                "message", ex.getMessage()
        );

        // Envolver todo en un ApiResponse
        ApiResponse<Map<String, Object>> response = new ApiResponse<>(meta, errorData);

        // Configurar respuesta HTTP
        exchange.getResponse().setStatusCode(status);
        exchange.getResponse().getHeaders().setContentType(MediaType.APPLICATION_JSON);

        try {
            // Serializar el ApiResponse completo, no solo el errorData
            byte[] bytes = mapper.writeValueAsBytes(response);
            var buffer = exchange.getResponse().bufferFactory().wrap(bytes);
            return exchange.getResponse().writeWith(Mono.just(buffer));
        } catch (Exception e) {
            log.error("Error writing error response", e);
            return exchange.getResponse().setComplete();
        }
    }
}
