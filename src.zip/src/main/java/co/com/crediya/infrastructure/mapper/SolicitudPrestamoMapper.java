package co.com.crediya.infrastructure.mapper;

import co.com.crediya.domain.model.SolicitudPrestamo;
import co.com.crediya.infrastructure.entity.SolicitudPrestamoEntity;
import co.com.crediya.infrastructure.entrypoints.dto.SolicitudPrestamoRequest;
import co.com.crediya.infrastructure.entrypoints.dto.SolicitudPrestamoResponse;

public class SolicitudPrestamoMapper {

    public static SolicitudPrestamo toDomain(SolicitudPrestamoRequest request) {
        return SolicitudPrestamo.builder()
                .documentoCliente(request.getDocumentoCliente())
                .monto(request.getMonto())
                .plazoMeses(request.getPlazoMeses())
                .tipoPrestamo(request.getTipoPrestamo())
                .estado("Pendiente de revisión")
                .build();
    }

    public static SolicitudPrestamoEntity toEntity(SolicitudPrestamo solicitudPrestamo) {
        SolicitudPrestamoEntity entity = new SolicitudPrestamoEntity();
        entity.setDocumentoCliente(solicitudPrestamo.getDocumentoCliente());
        /*entity.setClienteEmail(solicitudPrestamo.getClienteEmail());
        entity.setClienteNombre(solicitudPrestamo.getClienteNombre());*/
        entity.setMonto(solicitudPrestamo.getMonto());
        entity.setPlazoMeses(solicitudPrestamo.getPlazoMeses());
        entity.setTipoPrestamo(solicitudPrestamo.getTipoPrestamo());
        //entity.setTasaInteres(solicitudPrestamo.getTasaInteres());
        entity.setEstado(solicitudPrestamo.getEstado());
        /*entity.setSalarioBase(solicitudPrestamo.getSalarioBase());
        entity.setDeudaTotalMensualSolicitudesAprobadas(solicitudPrestamo.getDeudaTotalMensualSolicitudesAprobadas());*/
        return entity;
    }

    public static SolicitudPrestamoResponse toResponse(SolicitudPrestamoEntity entity) {
        return SolicitudPrestamoResponse.builder()
                .id(entity.getId())
                .documentoCliente(entity.getDocumentoCliente())
                /*.clienteEmail(entity.getClienteEmail())
                .clienteNombre(entity.getClienteNombre())*/
                .monto(entity.getMonto())
                .plazoMeses(entity.getPlazoMeses())
                .tipoPrestamo(entity.getTipoPrestamo())
                //.tasaInteres(entity.getTasaInteres())
                .estado(entity.getEstado())
                /*.salarioBase(entity.getSalarioBase())
                .deudaTotalMensualSolicitudesAprobadas(entity.getDeudaTotalMensualSolicitudesAprobadas())*/
                .build();
    }

    public static SolicitudPrestamoResponse toResponse(SolicitudPrestamo domain) {
        return SolicitudPrestamoResponse.builder()
                .id(domain.getId()) // <-- Aquí capturamos el id desde el domain
                .documentoCliente(domain.getDocumentoCliente())
                /*.clienteEmail(domain.getClienteEmail())
                .clienteNombre(domain.getClienteNombre())*/
                .monto(domain.getMonto())
                .plazoMeses(domain.getPlazoMeses())
                .tipoPrestamo(domain.getTipoPrestamo())
                //.tasaInteres(domain.getTasaInteres())
                .estado(domain.getEstado())
                /*.salarioBase(domain.getSalarioBase())
                .deudaTotalMensualSolicitudesAprobadas(domain.getDeudaTotalMensualSolicitudesAprobadas())*/
                .build();
    }

}
