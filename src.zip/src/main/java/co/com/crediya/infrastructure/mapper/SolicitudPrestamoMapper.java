package co.com.crediya.infrastructure.mapper;

import co.com.crediya.domain.model.SolicitudPrestamo;
import co.com.crediya.infrastructure.entity.SolicitudPrestamoEntity;
import co.com.crediya.infrastructure.entrypoints.dto.SolicitudPrestamoRequest;
import co.com.crediya.infrastructure.entrypoints.dto.SolicitudPrestamoResponse;

public class SolicitudPrestamoMapper {

    public static SolicitudPrestamo toDomain(SolicitudPrestamoRequest request) {
        return SolicitudPrestamo.builder()
                .documentoCliente(request.getDocumentoCliente())
                .monto(request.getMonto())
                .plazoMeses(request.getPlazoMeses())
                .tipoPrestamo(request.getTipoPrestamo())
                .estado("Pendiente de revisión")
                .build();
    }

    public static SolicitudPrestamoEntity toEntity(SolicitudPrestamo solicitudPrestamo) {
        SolicitudPrestamoEntity entity = new SolicitudPrestamoEntity();
        entity.setDocumentoCliente(solicitudPrestamo.getDocumentoCliente());
        entity.setMonto(solicitudPrestamo.getMonto());
        entity.setPlazoMeses(solicitudPrestamo.getPlazoMeses());
        entity.setTipoPrestamo(solicitudPrestamo.getTipoPrestamo());
        entity.setEstado(solicitudPrestamo.getEstado());
        return entity;
    }

    public static SolicitudPrestamoResponse toResponse(SolicitudPrestamoEntity entity) {
        return SolicitudPrestamoResponse.builder()
                .id(entity.getId())
                .documentoCliente(entity.getDocumentoCliente())
                .monto(entity.getMonto())
                .plazoMeses(entity.getPlazoMeses())
                .tipoPrestamo(entity.getTipoPrestamo())
                .estado(entity.getEstado())
                .build();
    }

    public static SolicitudPrestamoResponse toResponse(SolicitudPrestamo domain) {
        return SolicitudPrestamoResponse.builder()
                .id(domain.getId()) // <-- Aquí capturamos el id desde el domain
                .documentoCliente(domain.getDocumentoCliente())
                .monto(domain.getMonto())
                .plazoMeses(domain.getPlazoMeses())
                .tipoPrestamo(domain.getTipoPrestamo())
                .estado(domain.getEstado())
                .build();
    }

}
