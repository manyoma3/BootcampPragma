package co.com.crediya.infrastructure.entrypoints.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SolicitudPrestamoResponse {
    private Long id;
    private String documentoCliente;
    /*String clienteEmail;
    String clienteNombre;*/
    private Double monto;
    private Integer plazoMeses;
    private String tipoPrestamo;
    /*Double tasaInteres;*/
    private String estado;
    /*Double salarioBase;
    Double deudaTotalMensualSolicitudesAprobadas;*/
}
