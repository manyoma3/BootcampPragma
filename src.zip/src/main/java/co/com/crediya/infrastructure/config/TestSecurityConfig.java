package co.com.crediya.infrastructure.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;

@Configuration
@Profile("test") // Esta configuración solo aplica si el perfil activo es 'test'
@EnableWebFluxSecurity // Habilita Spring Security para WebFlux (reactivo)
public class TestSecurityConfig {

    @Bean
    public SecurityWebFilterChain testSecurityWebFilterChain(ServerHttpSecurity http) {
        return http
                .csrf(csrf -> csrf.disable())// Desactiva CSRF para permitir pruebas sin tokens
                .authorizeExchange(exchanges -> exchanges.anyExchange().permitAll()) // Permite todas las rutas sin autenticación
                .build();
    }
}
