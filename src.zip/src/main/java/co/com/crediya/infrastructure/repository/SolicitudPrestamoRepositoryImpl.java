package co.com.crediya.infrastructure.repository;

import co.com.crediya.infrastructure.entity.SolicitudPrestamoEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.StringJoiner;

@RequiredArgsConstructor
@Repository
public class SolicitudPrestamoRepositoryImpl implements SolicitudPrestamoRepositoryCustom {

    private final DatabaseClient db;

    @Override
    public Mono<Long> countByEstados(List<String> estados, String tipo, String email) {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT count(1) FROM solicitud_prestamo WHERE estado IN (");
        StringJoiner sj = new StringJoiner(",", "", ")");
        for (int i = 0; i < estados.size(); i++) {
            sj.add("$" + (i + 1));
        }
        sb.append(sj.toString());
        sb.append(")");

        int paramIndex = estados.size() + 1;
        if (tipo != null) {
            sb.append(" AND lower(tipo_prestamo) = lower($" + paramIndex++ + ")");
        }
        if (email != null) {
            sb.append(" AND lower(cliente_email) = lower($" + paramIndex++ + ")");
        }

        DatabaseClient.GenericExecuteSpec spec = db.sql(sb.toString());
        for (int i = 0; i < estados.size(); i++) spec = spec.bind(i, estados.get(i));
        int idx = estados.size();
        if (tipo != null) spec = spec.bind(idx++, tipo);
        if (email != null) spec = spec.bind(idx++, email);

        return spec.map(row -> row.get(0, Long.class)).one();
    }

    @Override
    public Flux<SolicitudPrestamoEntity> findByEstadosPaged(List<String> estados, String tipo, String email, int limit, int offset) {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT * FROM solicitud_prestamo WHERE estado IN (");
        StringJoiner sj = new StringJoiner(",", "", ")");
        for (int i = 0; i < estados.size(); i++) {
            sj.add("$" + (i + 1));
        }
        sb.append(sj.toString());
        sb.append(")");

        int paramIndex = estados.size() + 1;
        if (tipo != null) {
            sb.append(" AND lower(tipo_prestamo) = lower($" + paramIndex++ + ")");
        }
        if (email != null) {
            sb.append(" AND lower(cliente_email) = lower($" + paramIndex++ + ")");
        }

        sb.append(" ORDER BY id DESC LIMIT $" + paramIndex++ + " OFFSET $" + paramIndex);

        DatabaseClient.GenericExecuteSpec spec = db.sql(sb.toString());
        for (int i = 0; i < estados.size(); i++) spec = spec.bind(i, estados.get(i));
        int idx = estados.size();
        if (tipo != null) spec = spec.bind(idx++, tipo);
        if (email != null) spec = spec.bind(idx++, email);
        spec = spec.bind(idx++, limit);
        spec = spec.bind(idx, offset);

        return spec.map((row, metadata) -> {
            SolicitudPrestamoEntity e = new SolicitudPrestamoEntity();
            e.setId(row.get("id", Long.class));
            e.setDocumentoCliente(row.get("documento_cliente", String.class));
            /*e.setClienteEmail(row.get("cliente_email", String.class));
            e.setClienteNombre(row.get("cliente_nombre", String.class));*/
            e.setMonto(row.get("monto", Double.class));
            e.setPlazoMeses(row.get("plazo_meses", Integer.class));
            e.setTipoPrestamo(row.get("tipo_prestamo", String.class));
            //e.setTasaInteres(row.get("tasa_interes", Double.class));
            e.setEstado(row.get("estado", String.class));
            /*e.setSalarioBase(row.get("salario_base", Double.class));
            e.setDeudaTotalMensualSolicitudesAprobadas(row.get("deuda_total_mensual_solicitudes_aprobadas", Double.class));*/
            return e;
        }).all();
    }
}
