package co.com.crediya.infrastructure.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.ReactiveAuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.security.web.server.authentication.AuthenticationWebFilter;
import org.springframework.security.web.server.context.NoOpServerSecurityContextRepository;
import reactor.core.publisher.Mono;

import io.jsonwebtoken.Claims;

import java.util.List;

@RequiredArgsConstructor
@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {

    private final JwtVerifier jwtVerifier;

    // 🔑 Bean único para PasswordEncoder
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {
        return http
                .csrf(ServerHttpSecurity.CsrfSpec::disable)
                .authorizeExchange(ex -> ex
                        .pathMatchers("/api/v1/login").permitAll()
                        .pathMatchers("/actuator/**").permitAll()
                        .pathMatchers("/api/v1/usuarios").hasAnyRole("ADMIN", "ASESOR")
                        .pathMatchers("/api/v1/solicitudPrestamo").hasRole("CLIENTE")
                        //.pathMatchers("/api/v1/solicitud").hasRole("ASESOR")
                        .anyExchange().authenticated()
                )
                .addFilterAt(bearerFilter(), SecurityWebFiltersOrder.AUTHENTICATION)
                .build();
    }

    private AuthenticationWebFilter bearerFilter() {
        ReactiveAuthenticationManager authManager = authentication -> Mono.just(authentication);

        AuthenticationWebFilter filter = new AuthenticationWebFilter(authManager);

        filter.setServerAuthenticationConverter(this::convert);
        filter.setSecurityContextRepository(NoOpServerSecurityContextRepository.getInstance());

        return filter;
    }

    private Mono<Authentication> convert(org.springframework.web.server.ServerWebExchange exchange) {
        String authHeader = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return Mono.empty(); // no hay token → se permite el acceso a /login
        }

        String token = authHeader.substring(7);
        Claims claims;
        try {
            claims = jwtVerifier.parse(token);
        } catch (Exception e) {
            return Mono.error(new BadCredentialsException("Invalid JWT", e));
        }

        String role = "ROLE_" + claims.get("role", String.class);
        String email = claims.getSubject();

        AbstractAuthenticationToken auth = new AbstractAuthenticationToken(
                List.of(new SimpleGrantedAuthority(role))) {
            @Override public Object getCredentials() { return token; }
            @Override public Object getPrincipal() { return email; }
        };
        auth.setAuthenticated(true);

        return Mono.just(auth);
    }
}
