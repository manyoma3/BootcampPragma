package co.com.crediya.infrastructure.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;

@Configuration
@EnableWebFluxSecurity // Habilita seguridad reactiva con Spring Security
public class SecurityConfig {

    // Bean que define la cadena de filtros de seguridad
    @Bean
    public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {
        return http
                .csrf(ServerHttpSecurity.CsrfSpec::disable) // Desactiva protección CSRF (útil en APIs o pruebas con Postman)
                .authorizeExchange(exchanges -> exchanges
                        .anyExchange().permitAll() //Permite el acceso a todas las rutas sin autenticación
                )
                .build();
    }
}
