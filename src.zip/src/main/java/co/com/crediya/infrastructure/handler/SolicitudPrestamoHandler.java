package co.com.crediya.infrastructure.handler;

import co.com.crediya.application.usecase.RegistrarSolicitudPrestamoUseCase;
import co.com.crediya.infrastructure.config.JwtVerifier;
import co.com.crediya.infrastructure.entrypoints.dto.*;
import co.com.crediya.infrastructure.mapper.SolicitudPrestamoMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

// infrastructure/handler/SolicitudPrestamoHandler.java (solo el fragmento clave)
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.core.Authentication;

@Slf4j
@Component
@RequiredArgsConstructor
public class SolicitudPrestamoHandler {

    private final RegistrarSolicitudPrestamoUseCase useCase;
    private final JwtVerifier jwtVerifier;


    public Mono<ServerResponse> registrar(ServerRequest request) {
        return request.bodyToMono(SolicitudPrestamoRequest.class)
                .zipWith(ReactiveSecurityContextHolder.getContext().map(ctx -> ctx.getAuthentication()))
                /*.flatMap(req -> {
                    log.info("Recibiendo solicitud: {}", req);
                    if (req.getMonto() <= 0 || req.getPlazoMeses() <= 0) {
                        return Mono.error(new IllegalArgumentException("Monto y plazo deben ser mayores a 0"));
                    }
                    // Validación del tipo de préstamo
                    if (!req.getTipoPrestamo().matches("(?i)personal|hipotecario|vehicular")) {
                        return Mono.error(new IllegalArgumentException("Tipo de préstamo inválido"));
                    }
                    return useCase.registrar(SolicitudPrestamoMapper.toDomain(req));
                })*/
                .flatMap(tuple -> {
                    var req = tuple.getT1();
                    Authentication auth = tuple.getT2();

                    // Validaciones ya existentes...
                    if (req.getMonto() <= 0 || req.getPlazoMeses() <= 0)
                        return Mono.error(new IllegalArgumentException("Monto y plazo deben ser mayores a 0"));

                    // Si es CLIENTE, obligar a que su documento coincida
                    boolean isCliente = auth.getAuthorities().stream()
                            .anyMatch(a -> a.getAuthority().equals("ROLE_CLIENTE"));

                    if (isCliente) {
                        // El 'doc' viene en el JWT; lo recuperamos desde SecurityContext si lo propagas como detail
                        // Alternativa: volver a parsear el token del header aquí y leer 'doc' con JwtVerifier.
                        String header = request.headers().firstHeader("Authorization");
                        String token = header.substring(7);
                        String docToken = jwtVerifier.parse(token).get("doc", String.class);
                        if (!docToken.equals(req.getDocumentoCliente())) {
                            return Mono.error(new IllegalArgumentException("Documento no coincide con el usuario autenticado"));
                        }
                    }

                    return useCase.registrar(SolicitudPrestamoMapper.toDomain(req));
                })
                .map(SolicitudPrestamoMapper::toResponse)
                .flatMap(resp -> {
                    String messageId = request.headers().firstHeader("messageId");
                    String applicationId = request.headers().firstHeader("applicationId");
                    String requestDateTime = OffsetDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);

                    Meta meta = new Meta(messageId, requestDateTime, applicationId);
                    ApiResponse<SolicitudPrestamoResponse> response = new ApiResponse<>(meta, resp);

                    return ServerResponse.ok()
                            .contentType(MediaType.APPLICATION_JSON)
                            .bodyValue(response);
                });
    }


}
