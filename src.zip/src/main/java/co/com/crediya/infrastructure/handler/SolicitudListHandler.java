package co.com.crediya.infrastructure.handler;

import co.com.crediya.application.usecase.ListarSolicitudesUseCase;
import co.com.crediya.infrastructure.entrypoints.dto.*;
import co.com.crediya.infrastructure.mapper.SolicitudPrestamoMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class SolicitudListHandler {

    private final ListarSolicitudesUseCase useCase;

    /*public Mono<ServerResponse> listar(ServerRequest request) {
        int page = Integer.parseInt(request.queryParam("page").orElse("0"));
        int size = Integer.parseInt(request.queryParam("size").orElse("10"));
        String tipo = request.queryParam("tipo").orElse(null);
        String email = request.queryParam("email").orElse(null);

        log.debug("SolicitudListHandler.listar page={} size={} tipo={} email={}", page, size, tipo, email);

        return ReactiveSecurityContextHolder.getContext()
                .map(ctx -> ctx.getAuthentication())
                .flatMap(auth -> {
                    boolean isAsesor = auth.getAuthorities().stream()
                            .anyMatch(a -> a.getAuthority().equals("ROLE_ASESOR"));

                    if (!isAsesor) {
                        log.warn("Acceso denegado para usuario {}", auth.getName());
                        return Mono.error(new AccessDeniedException("Acceso denegado"));
                    }

                    return useCase.list(page, size, tipo, email)
                            .flatMap(paged -> {
                                // map domain -> dto
                                var items = paged.getItems().stream()
                                        .map(co.com.crediya.infrastructure.mapper.SolicitudPrestamoMapper::toResponse)
                                        .collect(Collectors.toList());

                                PagedResponse<SolicitudPrestamoResponse> responseData = PagedResponse.<SolicitudPrestamoResponse>builder()
                                        .items(items)
                                        .total(paged.getTotal())
                                        .page(paged.getPage())
                                        .size(paged.getSize())
                                        .build();

                                // meta
                                String messageId = request.headers().firstHeader("messageId");
                                if (messageId == null) messageId = UUID.randomUUID().toString();
                                String applicationId = request.headers().firstHeader("applicationId");
                                if (applicationId == null) applicationId = "solicitudPrestamos-app";
                                String requestDateTime = OffsetDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
                                Meta meta = new Meta(messageId, requestDateTime, applicationId);

                                ApiResponse<PagedResponse<SolicitudPrestamoResponse>> apiResp = new ApiResponse<>(meta, responseData);

                                return ServerResponse.ok()
                                        .contentType(MediaType.APPLICATION_JSON)
                                        .bodyValue(apiResp);
                            });
                });
    }*/
}
